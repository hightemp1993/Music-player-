"""Run after `flutter create . --platforms=android`.

Adds the permissions + background-audio service entries the player needs,
renames the app, and switches MainActivity to AudioServiceActivity.
"""
import glob
import re

MANIFEST = "android/app/src/main/AndroidManifest.xml"

PERMISSIONS = """
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
"""

SERVICE = """
        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService"/>
            </intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON"/>
            </intent-filter>
        </receiver>
"""

with open(MANIFEST, encoding="utf-8") as f:
    xml = f.read()

if "READ_MEDIA_AUDIO" not in xml:
    xml = xml.replace("<application", PERMISSIONS + "    <application", 1)
    xml = xml.replace("</application>", SERVICE + "    </application>", 1)
    xml = re.sub(r'android:label="[^"]*"', 'android:label="Sonic Music"', xml, count=1)

with open(MANIFEST, "w", encoding="utf-8") as f:
    f.write(xml)

for path in glob.glob("android/app/src/main/kotlin/**/MainActivity.kt", recursive=True):
    with open(path, encoding="utf-8") as f:
        src = f.read()
    pkg = re.search(r"^package\s+([\w.]+)", src, re.M).group(1)
    with open(path, "w", encoding="utf-8") as f:
        f.write(
            f"package {pkg}\n\n"
            "import com.ryanheise.audioservice.AudioServiceActivity\n\n"
            "class MainActivity : AudioServiceActivity()\n"
        )

print("Android project patched.")
