import 'package:flutter/material.dart';

const kAccent = Color(0xFFFF6A13);
const kAccentSoft = Color(0x33FF6A13);
const kBg = Color(0xFF0B0B0C);
const kSurface = Color(0xFF161618);
const kSurface2 = Color(0xFF232326);

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: kBg,
    colorScheme: const ColorScheme.dark(
      primary: kAccent,
      surface: kSurface,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: kBg,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(
        fontSize: 26,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.5,
        color: Colors.white,
      ),
    ),
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: kSurface,
      indicatorColor: kAccentSoft,
      height: 64,
    ),
    sliderTheme: const SliderThemeData(
      activeTrackColor: kAccent,
      inactiveTrackColor: Colors.white24,
      thumbColor: kAccent,
      trackHeight: 3,
      thumbShape: RoundSliderThumbShape(enabledThumbRadius: 6),
      overlayShape: RoundSliderOverlayShape(overlayRadius: 14),
    ),
  );
}

String fmt(Duration d) {
  final m = d.inMinutes;
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return '$m:$s';
}
