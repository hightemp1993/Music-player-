import 'package:flutter/material.dart';
import 'package:on_audio_query_forked/on_audio_query.dart';
import 'package:permission_handler/permission_handler.dart';

import '../player_service.dart';
import '../theme.dart';
import '../widgets/artwork.dart';
import '../widgets/mini_player.dart';
import '../widgets/song_tile.dart';
import 'song_list_page.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  bool? _granted;

  static const _titles = ['Songs', 'Albums', 'Artists'];

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final ok = await PlayerService.instance.ensurePermission();
    if (mounted) setState(() => _granted = ok);
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_granted == null) {
      body = const Center(child: CircularProgressIndicator(color: kAccent));
    } else if (_granted == false) {
      body = Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.library_music, size: 64, color: kAccent),
              const SizedBox(height: 16),
              const Text(
                'Allow access to your music so Sonic can play the songs on this phone.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: kAccent),
                onPressed: () async {
                  await _init();
                  if (_granted == false) await openAppSettings();
                },
                child: const Text('Grant access'),
              ),
            ],
          ),
        ),
      );
    } else {
      body = IndexedStack(
        index: _tab,
        children: const [_SongsTab(), _AlbumsTab(), _ArtistsTab()],
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(_titles[_tab])),
      body: body,
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const MiniPlayer(),
          NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: const [
              NavigationDestination(
                  icon: Icon(Icons.music_note_outlined),
                  selectedIcon: Icon(Icons.music_note, color: kAccent),
                  label: 'Songs'),
              NavigationDestination(
                  icon: Icon(Icons.album_outlined),
                  selectedIcon: Icon(Icons.album, color: kAccent),
                  label: 'Albums'),
              NavigationDestination(
                  icon: Icon(Icons.person_outline),
                  selectedIcon: Icon(Icons.person, color: kAccent),
                  label: 'Artists'),
            ],
          ),
        ],
      ),
    );
  }
}

class _SongsTab extends StatefulWidget {
  const _SongsTab();
  @override
  State<_SongsTab> createState() => _SongsTabState();
}

class _SongsTabState extends State<_SongsTab> {
  late final Future<List<SongModel>> _future = PlayerService.instance.loadSongs();
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<SongModel>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator(color: kAccent));
        }
        final all = snap.data ?? [];
        if (all.isEmpty) {
          return const Center(child: Text('No music found on this device'));
        }
        final q = _q.toLowerCase();
        final list = q.isEmpty
            ? all
            : all
                .where((s) =>
                    s.title.toLowerCase().contains(q) ||
                    (s.artist ?? '').toLowerCase().contains(q))
                .toList();
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: TextField(
                onChanged: (v) => setState(() => _q = v),
                decoration: InputDecoration(
                  hintText: 'Search songs or artists',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: kSurface,
                  contentPadding: EdgeInsets.zero,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(28),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Text('${list.length} songs',
                      style: const TextStyle(color: Colors.white54)),
                  const Spacer(),
                  TextButton.icon(
                    style: TextButton.styleFrom(foregroundColor: kAccent),
                    icon: const Icon(Icons.shuffle, size: 18),
                    label: const Text('Shuffle all'),
                    onPressed: () => PlayerService.instance
                        .playQueue(list, 0, shuffle: true),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: list.length,
                itemBuilder: (_, i) => SongTile(
                  song: list[i],
                  onTap: () => PlayerService.instance.playQueue(list, i),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _AlbumsTab extends StatefulWidget {
  const _AlbumsTab();
  @override
  State<_AlbumsTab> createState() => _AlbumsTabState();
}

class _AlbumsTabState extends State<_AlbumsTab> {
  late final Future<List<AlbumModel>> _future = PlayerService.instance.loadAlbums();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<AlbumModel>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator(color: kAccent));
        }
        final albums = snap.data ?? [];
        if (albums.isEmpty) return const Center(child: Text('No albums'));
        final w = (MediaQuery.of(context).size.width - 16 * 3) / 2;
        return GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
            childAspectRatio: w / (w + 52),
          ),
          itemCount: albums.length,
          itemBuilder: (context, i) {
            final a = albums[i];
            return InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SongListPage(
                    title: a.album,
                    type: AudiosFromType.ALBUM_ID,
                    id: a.id,
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Artwork(
                      id: a.id, type: ArtworkType.ALBUM, size: w, radius: 14),
                  const SizedBox(height: 8),
                  Text(a.album,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  Text(cleanArtist(a.artist),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white54, fontSize: 12)),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _ArtistsTab extends StatefulWidget {
  const _ArtistsTab();
  @override
  State<_ArtistsTab> createState() => _ArtistsTabState();
}

class _ArtistsTabState extends State<_ArtistsTab> {
  late final Future<List<ArtistModel>> _future = PlayerService.instance.loadArtists();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<ArtistModel>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator(color: kAccent));
        }
        final artists = snap.data ?? [];
        if (artists.isEmpty) return const Center(child: Text('No artists'));
        return ListView.builder(
          itemCount: artists.length,
          itemBuilder: (context, i) {
            final a = artists[i];
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16),
              leading: Artwork(
                  id: a.id,
                  type: ArtworkType.ARTIST,
                  size: 52,
                  circle: true),
              title: Text(cleanArtist(a.artist),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text('${a.numberOfTracks ?? 0} songs',
                  style: const TextStyle(color: Colors.white54)),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SongListPage(
                    title: cleanArtist(a.artist),
                    type: AudiosFromType.ARTIST_ID,
                    id: a.id,
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
