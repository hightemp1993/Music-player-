import 'package:flutter/material.dart';
import 'package:on_audio_query_forked/on_audio_query.dart';

import '../player_service.dart';
import '../theme.dart';
import '../widgets/mini_player.dart';
import '../widgets/song_tile.dart';

/// Songs of one album or artist.
class SongListPage extends StatelessWidget {
  const SongListPage({
    super.key,
    required this.title,
    required this.type,
    required this.id,
  });

  final String title;
  final AudiosFromType type;
  final int id;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 20)),
      ),
      body: FutureBuilder<List<SongModel>>(
        future: PlayerService.instance.songsFrom(type, id),
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator(color: kAccent));
          }
          final list = snap.data ?? [];
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(
                            backgroundColor: kAccent,
                            foregroundColor: Colors.white),
                        icon: const Icon(Icons.play_arrow),
                        label: const Text('Play'),
                        onPressed: () =>
                            PlayerService.instance.playQueue(list, 0),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.shuffle),
                        label: const Text('Shuffle'),
                        onPressed: () => PlayerService.instance
                            .playQueue(list, 0, shuffle: true),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) => SongTile(
                    song: list[i],
                    onTap: () => PlayerService.instance.playQueue(list, i),
                  ),
                ),
              ),
              const MiniPlayer(),
            ],
          );
        },
      ),
    );
  }
}
