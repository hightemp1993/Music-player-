import 'dart:math';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';

import '../player_service.dart';
import '../theme.dart';
import '../widgets/artwork.dart';

void openNowPlaying(BuildContext context) {
  Navigator.of(context).push(PageRouteBuilder(
    pageBuilder: (_, __, ___) => const NowPlayingScreen(),
    transitionsBuilder: (_, anim, __, child) => SlideTransition(
      position: Tween(begin: const Offset(0, 1), end: Offset.zero)
          .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
      child: child,
    ),
  ));
}

class NowPlayingScreen extends StatelessWidget {
  const NowPlayingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = PlayerService.instance.player;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF2E1709), kBg],
            stops: [0.0, 0.7],
          ),
        ),
        child: SafeArea(
          child: StreamBuilder<SequenceState?>(
            stream: p.sequenceStateStream,
            builder: (context, snap) {
              final item = snap.data?.currentSource?.tag;
              if (item is! MediaItem) {
                return const Center(child: Text('Nothing playing'));
              }
              return LayoutBuilder(builder: (context, box) {
                final art = min(box.maxWidth - 56, box.maxHeight * 0.42);
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.keyboard_arrow_down, size: 32),
                            onPressed: () => Navigator.pop(context),
                          ),
                          const Expanded(
                            child: Text(
                              'NOW PLAYING',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  letterSpacing: 2,
                                  fontSize: 12,
                                  color: Colors.white60),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.queue_music),
                            onPressed: () => _showQueue(context),
                          ),
                        ],
                      ),
                      const Spacer(),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(22),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0x66FF6A13),
                                blurRadius: 40,
                                spreadRadius: -8),
                          ],
                        ),
                        child: Artwork(
                            id: int.parse(item.id), size: art, radius: 22),
                      ),
                      const Spacer(),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(item.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 24, fontWeight: FontWeight.w800)),
                      ),
                      const SizedBox(height: 4),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(item.artist ?? '',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 16, color: Colors.white60)),
                      ),
                      const SizedBox(height: 12),
                      _SeekBar(player: p),
                      const SizedBox(height: 8),
                      _Controls(player: p),
                      const SizedBox(height: 24),
                    ],
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  void _showQueue(BuildContext context) {
    final p = PlayerService.instance.player;
    showModalBottomSheet(
      context: context,
      backgroundColor: kSurface,
      showDragHandle: true,
      builder: (_) {
        final seq = p.sequence ?? [];
        return ListView.builder(
          itemCount: seq.length,
          itemBuilder: (context, i) {
            final tag = seq[i].tag;
            if (tag is! MediaItem) return const SizedBox.shrink();
            final active = i == p.currentIndex;
            return ListTile(
              leading: Artwork(id: int.parse(tag.id), size: 44),
              title: Text(tag.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: active ? kAccent : Colors.white)),
              subtitle: Text(tag.artist ?? '',
                  maxLines: 1,
                  style: const TextStyle(color: Colors.white54)),
              onTap: () {
                p.seek(Duration.zero, index: i);
                Navigator.pop(context);
              },
            );
          },
        );
      },
    );
  }
}

class _SeekBar extends StatelessWidget {
  const _SeekBar({required this.player});
  final AudioPlayer player;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration?>(
      stream: player.durationStream,
      builder: (context, d) {
        final total = d.data ?? Duration.zero;
        final maxV = max(total.inMilliseconds.toDouble(), 1.0);
        return StreamBuilder<Duration>(
          stream: player.positionStream,
          builder: (context, pos) {
            final cur = pos.data ?? Duration.zero;
            final v = cur.inMilliseconds.toDouble().clamp(0.0, maxV);
            return Column(
              children: [
                Slider(
                  value: v,
                  min: 0,
                  max: maxV,
                  onChanged: (x) =>
                      player.seek(Duration(milliseconds: x.toInt())),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(fmt(cur),
                          style: const TextStyle(
                              color: Colors.white54, fontSize: 12)),
                      Text(fmt(total),
                          style: const TextStyle(
                              color: Colors.white54, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls({required this.player});
  final AudioPlayer player;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        StreamBuilder<bool>(
          stream: player.shuffleModeEnabledStream,
          builder: (context, s) {
            final on = s.data ?? false;
            return IconButton(
              icon: Icon(Icons.shuffle, color: on ? kAccent : Colors.white70),
              onPressed: () async {
                if (!on) await player.shuffle();
                await player.setShuffleModeEnabled(!on);
              },
            );
          },
        ),
        IconButton(
          iconSize: 40,
          icon: const Icon(Icons.skip_previous),
          onPressed: player.seekToPrevious,
        ),
        StreamBuilder<PlayerState>(
          stream: player.playerStateStream,
          builder: (context, s) {
            final st = s.data;
            final busy = st?.processingState == ProcessingState.loading ||
                st?.processingState == ProcessingState.buffering;
            final playing = st?.playing ?? false;
            return Container(
              width: 72,
              height: 72,
              decoration:
                  const BoxDecoration(color: kAccent, shape: BoxShape.circle),
              child: busy
                  ? const Padding(
                      padding: EdgeInsets.all(22),
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 3),
                    )
                  : IconButton(
                      iconSize: 40,
                      color: Colors.white,
                      icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                      onPressed: playing ? player.pause : player.play,
                    ),
            );
          },
        ),
        IconButton(
          iconSize: 40,
          icon: const Icon(Icons.skip_next),
          onPressed: player.seekToNext,
        ),
        StreamBuilder<LoopMode>(
          stream: player.loopModeStream,
          builder: (context, s) {
            final mode = s.data ?? LoopMode.off;
            return IconButton(
              icon: Icon(
                mode == LoopMode.one ? Icons.repeat_one : Icons.repeat,
                color: mode == LoopMode.off ? Colors.white70 : kAccent,
              ),
              onPressed: () => player.setLoopMode(
                  LoopMode.values[(mode.index + 1) % LoopMode.values.length]),
            );
          },
        ),
      ],
    );
  }
}
