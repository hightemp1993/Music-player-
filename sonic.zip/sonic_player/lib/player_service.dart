import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:on_audio_query_forked/on_audio_query.dart';
import 'package:permission_handler/permission_handler.dart';

/// Single shared player + media-store access.
class PlayerService {
  PlayerService._();
  static final PlayerService instance = PlayerService._();

  final AudioPlayer player = AudioPlayer();
  final OnAudioQuery query = OnAudioQuery();

  Future<bool> ensurePermission() async {
    // Android 13+ uses READ_MEDIA_AUDIO, older versions use storage.
    if (await Permission.audio.request().isGranted) return true;
    if (await Permission.storage.request().isGranted) return true;
    return false;
  }

  Future<List<SongModel>> loadSongs() async {
    final all = await query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );
    return all
        .where((s) => (s.isMusic ?? true) && (s.duration ?? 0) > 30000)
        .toList();
  }

  Future<List<AlbumModel>> loadAlbums() => query.queryAlbums(
        sortType: AlbumSortType.ALBUM,
        orderType: OrderType.ASC_OR_SMALLER,
        uriType: UriType.EXTERNAL,
        ignoreCase: true,
      );

  Future<List<ArtistModel>> loadArtists() => query.queryArtists(
        sortType: ArtistSortType.ARTIST,
        orderType: OrderType.ASC_OR_SMALLER,
        uriType: UriType.EXTERNAL,
        ignoreCase: true,
      );

  Future<List<SongModel>> songsFrom(AudiosFromType type, int id) async {
    final list = await query.queryAudiosFrom(
      type,
      id,
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      ignoreCase: true,
    );
    return list.where((s) => (s.duration ?? 0) > 30000).toList();
  }

  Future<void> playQueue(List<SongModel> list, int index,
      {bool shuffle = false}) async {
    if (list.isEmpty) return;
    final sources = list
        .map((s) => AudioSource.uri(
              Uri.parse(s.uri!),
              tag: MediaItem(
                id: s.id.toString(),
                title: s.title,
                artist: cleanArtist(s.artist),
                album: s.album,
              ),
            ))
        .toList();
    await player.setAudioSource(
      ConcatenatingAudioSource(children: sources),
      initialIndex: index,
    );
    await player.setShuffleModeEnabled(shuffle);
    if (shuffle) await player.shuffle();
    player.play();
  }
}

String cleanArtist(String? a) =>
    (a == null || a.isEmpty || a == '<unknown>') ? 'Unknown artist' : a;
