import 'package:flutter/material.dart';
import 'package:on_audio_query_forked/on_audio_query.dart';

import '../theme.dart';

class Artwork extends StatelessWidget {
  const Artwork({
    super.key,
    required this.id,
    this.type = ArtworkType.AUDIO,
    this.size = 56,
    this.radius = 8,
    this.circle = false,
  });

  final int id;
  final ArtworkType type;
  final double size;
  final double radius;
  final bool circle;

  @override
  Widget build(BuildContext context) {
    final border = BorderRadius.circular(circle ? size : radius);
    return QueryArtworkWidget(
      id: id,
      type: type,
      size: size > 150 ? 800 : 300,
      quality: 100,
      artworkWidth: size,
      artworkHeight: size,
      artworkFit: BoxFit.cover,
      artworkBorder: border,
      keepOldArtwork: true,
      nullArtworkWidget: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: kSurface2, borderRadius: border),
        child: Icon(
          circle ? Icons.person : Icons.music_note,
          color: Colors.white38,
          size: size * 0.45,
        ),
      ),
    );
  }
}
