import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:on_audio_query_forked/on_audio_query.dart';

import '../player_service.dart';
import '../theme.dart';
import 'artwork.dart';

class SongTile extends StatelessWidget {
  const SongTile({super.key, required this.song, required this.onTap});

  final SongModel song;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<SequenceState?>(
      stream: PlayerService.instance.player.sequenceStateStream,
      builder: (context, snap) {
        final tag = snap.data?.currentSource?.tag;
        final active = tag is MediaItem && tag.id == song.id.toString();
        return ListTile(
          onTap: onTap,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16),
          leading: Artwork(id: song.id, size: 52),
          title: Text(
            song.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: active ? kAccent : Colors.white,
            ),
          ),
          subtitle: Text(
            cleanArtist(song.artist),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white54),
          ),
          trailing: active
              ? const Icon(Icons.graphic_eq, color: kAccent)
              : Text(
                  fmt(Duration(milliseconds: song.duration ?? 0)),
                  style: const TextStyle(color: Colors.white38, fontSize: 12),
                ),
        );
      },
    );
  }
}
