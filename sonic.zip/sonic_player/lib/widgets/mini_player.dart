import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';

import '../player_service.dart';
import '../screens/now_playing.dart';
import '../theme.dart';
import 'artwork.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final p = PlayerService.instance.player;
    return StreamBuilder<SequenceState?>(
      stream: p.sequenceStateStream,
      builder: (context, snap) {
        final item = snap.data?.currentSource?.tag;
        if (item is! MediaItem) return const SizedBox.shrink();
        return GestureDetector(
          onTap: () => openNowPlaying(context),
          child: Container(
            color: kSurface2,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                StreamBuilder<Duration>(
                  stream: p.positionStream,
                  builder: (context, pos) {
                    final total = p.duration?.inMilliseconds ?? 0;
                    final cur = pos.data?.inMilliseconds ?? 0;
                    final v = total == 0 ? 0.0 : (cur / total).clamp(0.0, 1.0);
                    return LinearProgressIndicator(
                      value: v,
                      minHeight: 2,
                      backgroundColor: Colors.white12,
                      color: kAccent,
                    );
                  },
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
                  child: Row(
                    children: [
                      Artwork(id: int.parse(item.id), size: 44),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600)),
                            Text(item.artist ?? '',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: Colors.white54, fontSize: 12)),
                          ],
                        ),
                      ),
                      StreamBuilder<PlayerState>(
                        stream: p.playerStateStream,
                        builder: (context, st) {
                          final playing = st.data?.playing ?? false;
                          return IconButton(
                            iconSize: 32,
                            icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                            onPressed: playing ? p.pause : p.play,
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.skip_next),
                        onPressed: p.seekToNext,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
