# Sonic Music

A dark, Walkman-inspired local music player for Android, built with Flutter.
Plays the songs stored on the phone. Songs, Albums and Artists tabs, search,
shuffle, a mini player, a full Now Playing screen, queue, and notification /
lock-screen controls.

## Get the APK (no setup on your PC)

1. Create a new GitHub repository and upload everything in this folder.
2. Open the **Actions** tab, choose **Build APK**, press **Run workflow**.
3. When it finishes, download `sonic-music-apk` from the run page, unzip it and
   install `app-release.apk` on your phone (allow "install unknown apps").

## Build on your own computer

Install Flutter and Android Studio, then in this folder:

```
flutter create . --project-name sonic_player --org com.example --platforms=android
python3 tool/patch_android.py
flutter pub get
flutter build apk --release
```

The APK appears in `build/app/outputs/flutter-apk/app-release.apk`.

## Notes

- Design is inspired by the layout of classic music players but uses its own
  name and colors; add your own icon in `android/app/src/main/res/mipmap-*`.
- Release builds are signed with the debug key, which is fine for personal use.
  Create a real keystore before publishing to the Play Store.
